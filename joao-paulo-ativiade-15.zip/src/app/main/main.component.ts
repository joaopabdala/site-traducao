import { NgFor } from '@angular/common';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-main',
  standalone: true,
  imports: [ NgFor ],
  templateUrl: './main.component.html',
  styleUrl: './main.component.scss'
})

export class MainComponent implements OnInit {
  texts: any[] = [];

  ngOnInit(): void {
    this.loadTexts();
  }

  loadTexts() {
    this.texts = JSON.parse(localStorage.getItem('texts') || '[]');
  }
}