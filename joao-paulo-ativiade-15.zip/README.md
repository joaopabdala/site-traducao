# site-traducao
Projeto feito para a matéria da faculdade de framework usando Angular 
